
from flask import Blueprint, render_template, request, redirect, url_for
from services.analysis_service import analyze_and_get_data
from .forms import AnalysisForm

analysis_routes = Blueprint('analysis_routes', __name__)

@analysis_routes.route('/analyze', methods=['GET', 'POST'])
def analyze():
    form = AnalysisForm()
    if form.validate_on_submit():
        instrument = form.instrument.data
        granularity = form.granularity.data
        start_date = form.start_date.data
        end_date = form.end_date.data
        result = analyze_and_get_data(instrument, granularity, start_date, end_date)
        return render_template('analysis_view.html', result=result)
    return render_template('analysis.html', form=form)

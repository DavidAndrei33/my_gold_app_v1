from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, IntegerField, DateField, SelectField, validators
from wtforms import StringField, SubmitField, FloatField
from wtforms.validators import DataRequired, NumberRange
from wtforms import TextAreaField, SubmitField
from wtforms.validators import DataRequired
print("Inside forms.py")


class MarketDataForm(FlaskForm):
    date = DateField('Data', [validators.InputRequired()])
    price = FloatField('Preț', [validators.InputRequired()])
    volume = IntegerField('Volum', [validators.InputRequired()])
    asset_type = SelectField('Tipul de Activ', choices=[('gold', 'Aur'), ('silver', 'Argint')], validators=[validators.InputRequired()])



class NewsForm(FlaskForm):
    news_content = TextAreaField('Introduceți știrile:', validators=[DataRequired()])
    submit = SubmitField('Analizează')



class AnalysisForm(FlaskForm):
    instrument = StringField('Instrument', validators=[DataRequired()])
    granularity = StringField('Granularity', validators=[DataRequired()])
    start_date = StringField('Start Date (YYYY-MM-DD)', validators=[DataRequired()])
    end_date = StringField('End Date (YYYY-MM-DD)', validators=[DataRequired()])
    submit = SubmitField('Analyze')

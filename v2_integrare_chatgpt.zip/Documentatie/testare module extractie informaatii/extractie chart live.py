from selenium import webdriver
from selenium.webdriver.common.by import By

# Calea către driver (poți să o omiți dacă ai adăugat driverul la PATH)
# driver_path = 'calea_catre_driver'

# Inițializează browserul
# browser = webdriver.Firefox(executable_path=driver_path)  # Pentru Firefox
browser = webdriver.Firefox()  # Dacă ai adăugat driverul la PATH

# Navighează către pagina web
browser.get('https://www.cashbackforex.com/ro/widgets/live-chart/EUR.USD')

# Așteaptă până când elementele sunt încărcate (poți ajusta timpul de așteptare)
browser.implicitly_wait(30)

# Încearcă să găsești elementul sau datele de interes
# De exemplu, pentru a extrage valoarea curentă a EUR/USD
# value_element = browser.find_element(By.CSS_SELECTOR, 'selector_css_corespunzator')
# value = value_element.text

# Tipărește valoarea
# print(value)

# Închide browserul
browser.quit()

from selenium import webdriver

# Setăm calea către driverul browserului (în acest caz, geckodriver pentru Firefox)
driver_path = 'path_to_geckodriver'

# Inițializăm browserul
browser = webdriver.Firefox(executable_path=driver_path)

# Navigăm către pagina cu graficul live
browser.get('https://www.cashbackforex.com/ro/widgets/live-chart/EUR.USD')

# Aici vom adăuga cod pentru a identifica și extrage datele...

# Închidem browserul după ce am terminat
browser.close()

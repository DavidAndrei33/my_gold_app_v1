from flask import Flask
from flask_pymongo import PyMongo
from routes.analysis_routes import analysis_routes
from routes.main_routes import main_routes

app = Flask(__name__)

# Configurarea aplicației
app.config["MONGO_URI"] = "mongodb://localhost:27017/my_gold_app_db"
app.config["WTF_CSRF_ENABLED"] = True
app.config["SECRET_KEY"] = 'o_cheie_secreta_aleatorie'

# Inițializează PyMongo
mongo = PyMongo(app)

# Înregistrarea blueprint-urilor
app.register_blueprint(analysis_routes)
app.register_blueprint(main_routes)

if __name__ == "__main__":
    app.run(debug=True)

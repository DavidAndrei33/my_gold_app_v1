function sendMessage() {
    const userInput = document.getElementById("user-input");
    const chatMessages = document.getElementById("chat-messages");

    // Display user's message
    const userMessage = document.createElement("div");
    userMessage.textContent = userInput.value;
    userMessage.style.textAlign = "right";
    userMessage.style.marginBottom = "10px";
    chatMessages.appendChild(userMessage);

    // Send message to backend
    fetch('/process_message', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: userInput.value })
    })
    .then(response => response.json())
    .then(data => {
        // Display response from the server
        const serverMessage = document.createElement("div");
        serverMessage.textContent = data.response;
        serverMessage.style.marginBottom = "10px";
        chatMessages.appendChild(serverMessage);
    });

    // Clear user input
    userInput.value = "";
}

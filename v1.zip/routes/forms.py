from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, IntegerField, DateField, SelectField, validators

class MarketDataForm(FlaskForm):
    date = DateField('Data', [validators.InputRequired()])
    price = FloatField('Preț', [validators.InputRequired()])
    volume = IntegerField('Volum', [validators.InputRequired()])
    asset_type = SelectField('Tipul de Activ', choices=[('gold', 'Aur'), ('silver', 'Argint')], validators=[validators.InputRequired()])

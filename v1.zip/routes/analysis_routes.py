from flask import Blueprint, render_template, redirect, url_for
from my_gold_app.services.analysis_service import analyze

analysis_bp = Blueprint('analysis_bp', __name__)

@analysis_bp.route('/analyze', methods=['GET', 'POST'])
def analyze_and_view():
    analysis_data = analyze()
    return render_template("analysis_view.html", data=analysis_data)


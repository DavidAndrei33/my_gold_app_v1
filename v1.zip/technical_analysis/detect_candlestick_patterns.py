import mplfinance as mpf
import matplotlib.dates as mdates

def visualize_candlestick_patterns(df, patterns_df):
    fig, axes = mpf.plot(df, type='candle', style='charles', returnfig=True,
                         title='Candlestick Patterns',
                         ylabel='Price',
                         figsize=(15, 10))

    ax1 = axes[0]

    # Listă cu toate paternurile pe care dorim să le verificăm
    all_patterns = [
        'CDLENGULFING', 'CDLHAMMER', 'CDLDOJI', 'CDLHARAMI', 'CDLSHOOTINGSTAR', 
        # ... adaugă toate paternurile pe care dorești să le verifici
    ]

    for pattern in all_patterns:
        for index, row in patterns_df.iterrows():
            if row[pattern] != 0:
                color = 'g' if row[pattern] == 100 else 'r'
                ax1.annotate(pattern, xy=(mdates.date2num(index), df.loc[index]['Close']),
                             xytext=(mdates.date2num(index), df.loc[index]['High'] + 50),
                             arrowprops=dict(facecolor=color, arrowstyle='->'),
                             fontsize=8)

    mpf.show()


#df = pd.read_csv('path_to_your_data.csv', parse_dates=['Date'], index_col='Date')
#patterns_df = detect_candlestick_patterns(df)
#visualize_candlestick_patterns(df, patterns_df)

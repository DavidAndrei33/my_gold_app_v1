
import matplotlib.pyplot as plt
import pandas as pd
import mplfinance as mpf

def plot_candlestick_data(df, detected_patterns_indices):
    # Create the candlestick plot
    mpf.plot(df, type='candle', style='charles', title='XAU/USD',
             ylabel='Price', figratio=(15, 10), volume=True, show_nontrading=True,
             hlines=dict(hlines=list(detected_patterns_indices.values()), colors='r', linestyle='-.'))
    plt.show()
    
import pandas as pd
import mplfinance as mpf
from my_gold_app.technical_analysis.candlestick_patterns import detect_candlestick_patterns

def analyze_and_plot_data(pair='xau/usd', timeframe='5m'):
    """
    Analyze and plot the data for the given pair and timeframe.
    """
    # Load the data
    path = f'data/{pair.replace("/", "")}/{timeframe}.csv'
    df = pd.read_csv(path)
    
    # Convert 'time' column to datetime format
    df['time'] = pd.to_datetime(df['time'])
    df.set_index('time', inplace=True)
    
    # Rename the columns to be compatible with mplfinance
    df = df[['open', 'high', 'low', 'close', 'volume']]
    
    # Detect patterns
    detected_patterns = detect_candlestick_patterns(df)
    
    # Highlight patterns in the chart
    # Note: You can customize the appearance as needed
    apdict = mpf.make_addplot(detected_patterns['Pattern_Score'])
    
    # Create the plot
    mpf.plot(df, type='candle', style='charles', volume=True, title=f'{pair.upper()} - {timeframe.upper()}', addplot=apdict)

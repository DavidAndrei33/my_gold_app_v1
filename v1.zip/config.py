MONGO_URI = "mongodb://localhost:27017/my_gold_app_db"
WTF_CSRF_ENABLED = True
SECRET_KEY = 'o_cheie_secreta_aleatorie'

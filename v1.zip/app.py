from flask import Flask, render_template
from pymongo import MongoClient
from my_gold_app.my_gold_app.my_gold_app.routes.analysis_routes  import analysis_bp
from routes.main_routes import main_routes


app = Flask(__name__)
app.config.from_object("config")

client = MongoClient(app.config["MONGO_URI"])
db = client.gold_db  # sau orice alt nume doriți pentru baza de date
app.register_blueprint(analysis_bp)


app.register_blueprint(main_routes)

if __name__ == "__main__":
    app.run()
